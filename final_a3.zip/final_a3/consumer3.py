from kafka import KafkaConsumer
import json
from collections import defaultdict

# Create a KafkaConsumer instance
consumer = KafkaConsumer('assignment-topic', bootstrap_servers='localhost:9092', group_id='my-group')

# Define parameters
min_support = 0.1

# Initialize data structures
itemset_support = defaultdict(int)  
total_transactions = 0  

# Function to update itemset support counts
def update_support(transaction):
    for item in transaction:
        # Convert the item to a hashable format
        item_hashable = frozenset(item.items())
        itemset_support[item_hashable] += 1

# Function to prune infrequent itemsets
def prune_itemsets():
    global itemset_support
    itemset_support = {itemset: support for itemset, support in itemset_support.items() if support / total_transactions >= min_support}

# Consume messages from the Kafka topic
for message in consumer:
    try:
        # Decode the message from bytes to string
        message_str = message.value.decode('utf-8')
        # Parsing the message string as JSON
        transaction = json.loads(message_str)
        
        # Update itemset support counts
        update_support(transaction)
        
        # Increment total number of transactions processed
        total_transactions += 1
        
        # Prune infrequent itemsets
        prune_itemsets()
        
        # Print real-time insights
        print("Real-time insights:")
        print("Frequent itemsets:", itemset_support)
    
    except Exception as e:
        print(f"Error processing message: {e}")

# Close the consumer
consumer.close()


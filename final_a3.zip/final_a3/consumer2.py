from kafka import KafkaConsumer
import json
from collections import defaultdict

# Create a KafkaConsumer instance
consumer = KafkaConsumer('assignment-topic', bootstrap_servers='localhost:9092', group_id='my-group')

itemsets = defaultdict(int)  # For counting single items
item_pairs = defaultdict(int)  # For counting item pairs

print("Consumer 2 running!")

# Define parameters for PCY algorithm
hash_bucket_size = 1000  # Size of the hash table
bitmap = [0] * hash_bucket_size  # Bitmap for counting hash collisions

# Process messages from the Kafka topic
for message in consumer:
    # Decode the message from bytes to string
    message_str = message.value.decode('utf-8')
    # Parse the message string as JSON
    transaction = json.loads(message_str)
    
    # Update itemsets dictionary with the items in the transaction
    for item in transaction:
        # Convert the item dictionary to a hashable string representation
        item_key = json.dumps(item, sort_keys=True)
        # Update the itemsets dictionary with the item key
        itemsets[item_key] += 1
    
    # Update item pairs counts based on the transactions
    for i in range(len(transaction)):
        for j in range(i + 1, len(transaction)):
            item1 = transaction[i]
            item2 = transaction[j]
            # Convert dictionaries into tuples of sorted key-value pairs
            item1_tuple = tuple(sorted(item1.items()))
            item2_tuple = tuple(sorted(item2.items()))
            pair = (item1_tuple, item2_tuple)
            pair_tuple = tuple(pair)
            item_pairs[pair_tuple] += 1
             
            # Hash the pair tuple
            hash_value = hash(pair_tuple) % hash_bucket_size
            bitmap[hash_value] += 1

    # Generate association rules based on the frequent item pairs
    association_rules = []
    for pair, count in item_pairs.items():
        support_pair = count
        # Convert the pair tuple back to a JSON string
        pair_key = json.dumps(pair, sort_keys=True)
        # Convert the pair key back to a tuple
        pair_tuple = tuple(pair)
        # Access support counts from itemsets
        support_item1 = itemsets.get(json.dumps(pair_tuple[0], sort_keys=True), 0)
        support_item2 = itemsets.get(json.dumps(pair_tuple[1], sort_keys=True), 0)
        
        # Calculate confidence
        if support_item1 > 0:
            confidence = support_pair / support_item1
            if confidence >= 0.5:
                association_rules.append((pair_key, confidence))

    # Display real-time insights
    print("Real-time insights:")
    print("Frequent itemsets:", itemsets)
    print("Association rules:", association_rules)

# Close the consumer
consumer.close()


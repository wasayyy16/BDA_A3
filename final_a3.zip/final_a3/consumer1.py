from kafka import KafkaConsumer
import json
from collections import defaultdict
from itertools import combinations

# Create a KafkaConsumer instance
consumer = KafkaConsumer('assignment-topic', bootstrap_servers='localhost:9092', group_id='my-group')

itemsets = defaultdict(int)  # For counting single items
item_pairs = defaultdict(int)  # For counting item pairs

print("Consumer 2 running!")

# Define parameters for Apriori algorithm
MIN_SUPPORT = 0.1
MIN_CONFIDENCE = 0.5

# Process messages from the Kafka topic
for message in consumer:
    try:
        # Decode the message from bytes to string
        message_str = message.value.decode('utf-8')
        # Parse the message string as JSON
        transaction = json.loads(message_str)
        
        # Ensure transaction is a dictionary
        if not isinstance(transaction, dict):
            raise TypeError("Transaction data is not a dictionary")
        
        # Convert the transaction into a tuple of sorted (key, value) pairs
        transaction_tuple = tuple(sorted(transaction.items()))
        
        # Update itemsets dictionary with the transaction
        itemsets[transaction_tuple] += 1
        
        # Update item pairs counts based on the transactions
        for pair in combinations(transaction_tuple, 2):
            pair_set = frozenset(pair)
            item_pairs[pair_set] += 1

        # Generate frequent itemsets of size 1
        frequent_itemsets = {item: count for item, count in itemsets.items() if count / len(transaction) >= MIN_SUPPORT}
        
        # Generate frequent itemsets of size greater than 1
        k = 2
        while frequent_itemsets:
            # Generate candidate itemsets
            candidates = set()
            for itemset1, count1 in frequent_itemsets.items():
                for itemset2, count2 in frequent_itemsets.items():
                    if len(itemset1.union(itemset2)) == k:
                        candidates.add(itemset1.union(itemset2))
            
            # Count support for candidate itemsets in the transactions
            candidate_counts = defaultdict(int)
            for candidate in candidates:
                for transaction_set in item_pairs:
                    if candidate.issubset(transaction_set):
                        candidate_counts[candidate] += 1
            
            # Prune infrequent itemsets
            frequent_itemsets = {itemset: count for itemset, count in candidate_counts.items() if count / len(transaction) >= MIN_SUPPORT}
            
            k += 1

        # Generate association rules
        association_rules = []
        for itemset, count in item_pairs.items():
            for item in itemset:
                antecedent = itemset - {item}
                confidence = count / itemsets[item]
                if confidence >= MIN_CONFIDENCE:
                    association_rules.append((antecedent, itemset - antecedent, confidence))

        # Display real-time insights
        print("Real-time insights:")
        print("Frequent itemsets:", {tuple(itemset): count for itemset, count in frequent_itemsets.items()})
        print("Association rules:", association_rules)
    
    except Exception as e:
        print(f"Error processing message: {e}")

# Close the consumer
consumer.close()


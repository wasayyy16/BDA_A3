from kafka import KafkaConsumer
import json
from collections import defaultdict

# Create a KafkaConsumer instance
consumer = KafkaConsumer('assignment-topic', bootstrap_servers='localhost:9092', group_id='my-group')


min_support = 0.1  
min_confidence = 0.5  


frequent_itemsets = defaultdict(int)  
total_transactions = 0  

#generation candidate itemsets
def generate_candidates(prev_itemsets, k):
    # generation of candidate itemsets of size k+1 from frequent itemsets of size k
    candidates = set()
    for itemset1 in prev_itemsets:
        for itemset2 in prev_itemsets:
            if itemset1 != itemset2 and len(itemset1.union(itemset2)) == k + 1:
                candidates.add(itemset1.union(itemset2))
    return candidates

# Function to prune infrequent itemsets
def prune_itemsets(itemsets, min_support):
    # Prune itemsets that do not meet the minimum support threshold
    return {itemset: count for itemset, count in itemsets.items() if count / total_transactions >= min_support}

# Function to generate association rules
def generate_association_rules(frequent_itemsets, min_confidence):
    association_rules = []
    for itemset, count in frequent_itemsets.items():
        if len(itemset) > 1:
            for item in itemset:
                antecedent = itemset - {item}
                confidence = count / frequent_itemsets[antecedent]
                if confidence >= min_confidence:
                    association_rules.append((antecedent, itemset - antecedent, confidence))
    return association_rules

#consuming messages from the Kafka topic
for message in consumer:
    # decoding the message f
    message_str = message.value.decode('utf-8')
    print(type(message_str))
    # Parsing the message  
    transaction = set(json.dumps(message_str))
    
    # updating the total number of transactions processed
    total_transactions += 1
    
    # generating frequent itemsets of size 1 
    for item in transaction:
        frequent_itemsets[frozenset([item])] += 1
    
    # generating frequent itemsets of size greaten than 1 
    k = 1
    while True:
        # generating candidate itemsets
        candidates = generate_candidates(frequent_itemsets.keys(), k)
        
        # counting support for candidate itemsets in the current transaction
        for candidate in candidates:
            if candidate.issubset(transaction):
                frequent_itemsets[candidate] += 1
        
        # Prune infrequent itemsets
        frequent_itemsets = prune_itemsets(frequent_itemsets, min_support)
        
        if len(frequent_itemsets) == 0:
            break
        
        k += 1
    
    # generation of association rules
    association_rules = generate_association_rules(frequent_itemsets, min_confidence)
    
    
    print("Real-time insights:")
    print("Frequent itemsets:", frequent_itemsets)
    print("Association rules:", association_rules)

# Close the consumer
consumer.close()


import json
import time
from kafka import KafkaProducer

# Creating a KafkaProducer instance
producer = KafkaProducer(bootstrap_servers='localhost:9092')

topic = 'assignment-topic'
chunk_size = 100

# Reading messages from the JSON file and sending them to the Kafka topic
with open('preprocessed_final1.json', 'r') as file:
    while True:
        data = []
        try:
            for _ in range(chunk_size):
                line = next(file)
                data.append(json.loads(line))
        except StopIteration:
            pass
        if not data:
            break
        
        for record in data:
            # Convert the record dictionary to JSON string
            message = json.dumps(record)
            # Encode the JSON string as bytes
            message_bytes = message.encode('utf-8')
            # Send the message to Kafka
            producer.send(topic, value=message_bytes)
            time.sleep(1)
            print("Data Published:", record)
    
# Closing the producer AND FLUSHING IT BEFORE CLOSING IT
producer.flush()
producer.close()


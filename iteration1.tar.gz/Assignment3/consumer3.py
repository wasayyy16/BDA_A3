from kafka import KafkaConsumer
import json
from collections import defaultdict

# Create a KafkaConsumer instance
consumer = KafkaConsumer('assignment-topic', bootstrap_servers='localhost:9092', group_id='my-group')
  
  #elcat algorithm
  
itemset_support = defaultdict(int)  
total_transactions = 0  
#support threshold
min_support = 0.1

#function to update itemset support counts
def update_support(transaction):
    for item in transaction:
        itemset_support[frozenset([item])] += 1

#function to prune infrequent itemsets
def prune_itemsets():
    global itemset_support
    itemset_support = {itemset: support for itemset, support in itemset_support.items() if support / total_transactions >= min_support}

#consume messages from the Kafka topic
for message in consumer:
    # Decoding the message from bytes to string
    message_str = message.value.decode('utf-8')
    # Parsing the message string as JSON
    transaction = json.loads(message_str)
    
    update_support(transaction)
    
    # Increment total number of transactions processed
    total_transactions += 1
    
    prune_itemsets()
    
    print("Real-time insights:")
    print("Frequent itemsets:", itemset_support)

# Close the consumer
consumer.close()


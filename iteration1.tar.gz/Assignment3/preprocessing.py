import json
#reading json file
filepath = '/content/smaller_sample.json'
dataset = []

with open(filepath, 'r') as json_file:
    for line in json_file:
        try:
            dataset.append(json.loads(line))
        except json.JSONDecodeError as e:
            print("Decoding JSON, naahhh! Just decoding individual lines and joining them toogether xD")

import pandas as pd
import json

# Reading JSON file
filepath = '/content/smaller_sample.json'
dataset = []

# Read each line of the JSON file
with open(filepath, 'r') as json_file:
    for line in json_file:
        try:
            # Convert each line to a Python dictionary
            data = json.loads(line)
            dataset.append(data)
        except json.JSONDecodeError as e:
            print("Decoding JSON, nah! Just decoding individual lines and joining them together xD")

# Convert list of dictionaries to DataFrame
df = pd.DataFrame(dataset)

# Drop irrelevant columns
df = df.drop(columns=['description'])

# Remove rows with missing values
df = df.dropna(axis=0, how='any')

# Fill missing values with mean of the column
#df['price'] = df['price'].fillna(df['price'].mean())
import pandas as pd

# Assuming 'column_name' is the column containing the problematic strings
# Remove dollar signs and hyphens from the column
df['price'] = df['price'].str.replace('$', '').str.replace('-', '')

# Convert the column to numeric values
try:
    df['price'] = pd.to_numeric(df['price'])
except ValueError as e:
    print(f"Error: {e}")

# Stripping leading and trailing whitespace from string column
df['brand'] = df['brand'].str.strip()

# Replace 'preprocessed_data.json' with the desired filename
df.to_json('preprocessed.json', orient='records')
